package com.BOOTJPA.BOOTJPA.tourfolder;

import jakarta.persistence.*;

@Entity
public class Tour {
    private Integer id;
    private String name;
    private String destination;
    private String date;
    private float price;
    private String description;
    private int days;
    private String url;
    private int bookings; // New field for bookings

    public Tour() {
    }

    public Tour(Integer id, String name, String destination, String date, float price, String description, int days, String url, int bookings) {
        this.id = id;
        this.name = name;
        this.destination = destination;
        this.date = date;
        this.price = price;
        this.description = description;
        this.days = days;
        this.url = url;
        this.bookings = bookings; // Initialize the bookings field
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getBookings() {
        return bookings;
    }

    public void setBookings(int bookings) {
        this.bookings = bookings;
    }
}
