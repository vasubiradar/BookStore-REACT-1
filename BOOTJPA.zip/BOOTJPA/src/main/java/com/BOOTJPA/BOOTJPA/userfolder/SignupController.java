package com.BOOTJPA.BOOTJPA.userfolder;
import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.ui.Model; 
import org.springframework.web.bind.annotation.*;





//ResponseEntity represents the whole HTTP response: status code, 
//headers, and body. As a result, we can use it to fully configure
//the HTTP response. If we want to use it, we have to return it from the endpoint;
//Spring takes care of the rest. ResponseEntity is a generic type

@CrossOrigin(origins = "http://localhost:3000")
@RestController
public class SignupController{
	 @Autowired
	    private UserService service;
	 
	   @GetMapping("/user")
	    public List<User> list() {
	        return service.listAll();
	    }
	
    @PostMapping("/user")
    public void add(@RequestBody User user) {
    	System.out.println("saved ");
    	
        service.save(user);
    }
	
}