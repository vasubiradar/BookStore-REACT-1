package com.BOOTJPA.BOOTJPA.couponfolder;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Coupon {
	
	private Integer id;
    private String coupon;
    
    public String getCoupon() {
		return coupon;
	}

	public void setCoupon(String coupon) {
		this.coupon = coupon;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer getId() {
        return id;
    }
	  public Coupon() {
	    }
	
	   public Coupon(Integer id, String coupon) {
	        this.id = id;
	        this.coupon = coupon;
	    }

}
