package com.BOOTJPA.BOOTJPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
